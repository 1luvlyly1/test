"""
Connect – kết nối tới Claude qua model service của Unity AI Gateway (Databricks).

    from rmd_llm import Connect
    llm = Connect()                       # tự dò host + token trong notebook
    print(llm.ask("Xin chào"))
"""
import json
import os
import random
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Iterator, List, Optional, Union

import requests

from ._auth import make_token_provider, resolve_host
from ._errors import GatewayError

DEFAULT_MODEL_SERVICE = os.environ.get("RMD_LLM_MODEL_SERVICE", "analytics_ai.rmd_bau.claude-sonnet-5-5-rmd_bau")
DEFAULT_API = os.environ.get("RMD_LLM_API", "gateway")

ROUTES = {
    "gateway": "/ai-gateway/mlflow/v1/chat/completions",     # OpenAI-compatible (giống cell test dùng OpenAI SDK)
    "anthropic": "/ai-gateway/anthropic/v1/messages",        # Anthropic Messages API gốc
}

Messages = Union[str, List[Dict[str, Any]]]


@dataclass
class ChatResponse:
    """Kết quả một lần gọi model. str(resp) == resp.text."""
    text: str
    model: str
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    latency_s: float = 0.0
    finish_reason: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    def __str__(self) -> str:
        return self.text


class Connect:
    """
    Kết nối tới model service qua Unity AI Gateway.

    Tham số
    -------
    model_service : tên đầy đủ <catalog>.<schema>.<service>
                    (mặc định analytics_ai.rmd_bau.claude-sonnet-5-5-rmd_bau, hoặc env RMD_LLM_MODEL_SERVICE)
    api           : "gateway" (mặc định, /ai-gateway/mlflow/v1/chat/completions) | "anthropic" (/ai-gateway/anthropic/v1/messages)
    host, token   : để trống → tự dò (env → spark.conf → notebook context → databricks-sdk)
    system        : system prompt mặc định cho mọi lần gọi
    max_tokens    : số token trả lời tối đa mặc định
    temperature   : None = không gửi (để model dùng mặc định)
    timeout       : giây chờ mỗi request
    retries       : số lần thử lại khi gặp 429 / 5xx / lỗi mạng
    """

    def __init__(self, model_service: Optional[str] = None, api: Optional[str] = None,
                 host: Optional[str] = None, token: Optional[str] = None, system: Optional[str] = None,
                 max_tokens: int = 4096, temperature: Optional[float] = None,
                 timeout: int = 300, retries: int = 3, verbose: bool = False):
        self.model_service = (model_service or DEFAULT_MODEL_SERVICE).strip()
        if self.model_service.count(".") < 2:
            raise ValueError(f"model_service phải có dạng <catalog>.<schema>.<service>, nhận được '{self.model_service}'. "
                             "SDK chỉ gọi qua model service của AI Gateway, không gọi trực tiếp model.")
        self.api = (api or DEFAULT_API).strip().lower()
        if self.api not in ROUTES:
            raise ValueError(f"api phải là một trong {list(ROUTES)}")
        self.system, self.max_tokens, self.temperature = system, max_tokens, temperature
        self.timeout, self.retries, self.verbose = timeout, retries, verbose
        self.host, self.host_source = resolve_host(host)
        self._headers, self.auth_source = make_token_provider(token)
        self._session = requests.Session()

    # ------------------------------------------------------------------ thông tin
    @property
    def url(self) -> str:
        return self.host + ROUTES[self.api]

    def info(self) -> Dict[str, str]:
        """Thông tin kết nối (không chứa token)."""
        return {"model_service": self.model_service, "api": self.api, "url": self.url,
                "host_source": self.host_source, "auth_source": self.auth_source}

    def __repr__(self) -> str:
        return f"Connect(model_service='{self.model_service}', api='{self.api}', url='{self.url}', auth='{self.auth_source}')"

    # ------------------------------------------------------------------ gọi model
    def chat(self, messages: Messages, system: Optional[str] = None, max_tokens: Optional[int] = None,
             temperature: Optional[float] = None, model: Optional[str] = None, **extra) -> ChatResponse:
        """Gọi model với 1 prompt (str) hoặc danh sách messages [{'role': 'user'|'assistant', 'content': ...}]."""
        payload = self._payload(messages, system, max_tokens, temperature, model, extra)
        t0 = time.time()
        data = self._post(payload)
        res = self._parse(data, payload["model"])
        res.latency_s = round(time.time() - t0, 2)
        if self.verbose:
            print(f"[rmd_llm] {res.latency_s}s · {res.input_tokens}→{res.output_tokens} tokens · {self.model_service}", file=sys.stderr)
        return res

    def ask(self, prompt: str, system: Optional[str] = None, **kw) -> str:
        """Hỏi 1 câu, nhận lại chuỗi trả lời."""
        return self.chat(prompt, system=system, **kw).text

    def stream(self, messages: Messages, system: Optional[str] = None, max_tokens: Optional[int] = None,
               temperature: Optional[float] = None, model: Optional[str] = None, **extra) -> Iterator[str]:
        """Trả lời dạng luồng (từng đoạn chữ). Dùng: for chunk in llm.stream('...'): print(chunk, end='')"""
        payload = self._payload(messages, system, max_tokens, temperature, model, extra)
        payload["stream"] = True
        r = self._request(payload, stream=True)
        try:
            for line in r.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data:"):
                    continue
                body = line[5:].strip()
                if body == "[DONE]":
                    break
                try:
                    obj = json.loads(body)
                except ValueError:
                    continue
                chunk = self._delta_text(obj)
                if chunk:
                    yield chunk
        finally:
            r.close()

    def ask_json(self, prompt: str, system: Optional[str] = None, retries: int = 1, **kw) -> Any:
        """Hỏi và nhận về object JSON (dict/list). Tự yêu cầu model sửa nếu JSON lỗi."""
        sys_msg = ((system or self.system or "") + "\nReturn ONLY valid JSON. No prose, no markdown fences.").strip()
        messages: List[Dict[str, Any]] = [{"role": "user", "content": prompt}]
        last_err = None
        for _ in range(retries + 1):
            text = self.chat(messages, system=sys_msg, **kw).text
            try:
                return extract_json(text)
            except ValueError as ex:
                last_err = ex
                messages += [{"role": "assistant", "content": text},
                             {"role": "user", "content": f"That was not valid JSON ({ex}). Return only the corrected JSON."}]
        raise ValueError(f"Model không trả về JSON hợp lệ: {last_err}")

    def ask_many(self, prompts: Iterable[str], system: Optional[str] = None, max_workers: int = 4,
                 on_error: str = "raise", progress: bool = True, **kw) -> List[Optional[str]]:
        """Hỏi nhiều prompt song song, giữ nguyên thứ tự. on_error='none' → lỗi thì trả None thay vì dừng."""
        items = list(prompts)
        out: List[Optional[str]] = [None] * len(items)
        done = [0]

        def work(i):
            try:
                out[i] = self.ask(items[i], system=system, **kw)
            except Exception:
                if on_error == "raise":
                    raise
                out[i] = None
            finally:
                done[0] += 1
                if progress and (done[0] % max(1, len(items) // 10) == 0 or done[0] == len(items)):
                    print(f"[rmd_llm] {done[0]}/{len(items)}", file=sys.stderr)

        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            list(ex.map(work, range(len(items))))
        return out

    def conversation(self, system: Optional[str] = None) -> "Conversation":
        """Hội thoại nhiều lượt, tự nhớ lịch sử."""
        return Conversation(self, system)

    def ping(self) -> ChatResponse:
        """Kiểm tra nhanh kết nối + quyền."""
        return self.chat("ping", system="Reply with exactly: OK", max_tokens=16)

    def openai_client(self):
        """OpenAI client trỏ vào AI Gateway (cho thư viện cần OpenAI SDK, vd LangChain). Cần `pip install openai`.
        Lưu ý: token được lấy tại thời điểm tạo client."""
        if self.api != "gateway":
            raise ValueError("openai_client() chỉ dùng với api='gateway'.")
        from openai import OpenAI  # type: ignore
        token = self._headers()["Authorization"].split(" ", 1)[1]
        return OpenAI(api_key=token, base_url=self.host + "/ai-gateway/mlflow/v1")

    # ------------------------------------------------------------------ nội bộ
    def _payload(self, messages, system, max_tokens, temperature, model, extra) -> Dict[str, Any]:
        msgs = [{"role": "user", "content": messages}] if isinstance(messages, str) else list(messages)
        if not msgs:
            raise ValueError("messages rỗng.")
        system = system if system is not None else self.system
        sys_in_msgs = [m for m in msgs if m.get("role") == "system"]
        msgs = [m for m in msgs if m.get("role") != "system"]
        if sys_in_msgs and system is None:
            system = "\n".join(str(m.get("content", "")) for m in sys_in_msgs)
        temp = temperature if temperature is not None else self.temperature
        p: Dict[str, Any] = {"model": model or self.model_service, "max_tokens": max_tokens or self.max_tokens}
        if self.api == "anthropic":
            p["messages"] = msgs
            if system:
                p["system"] = system
        else:
            p["messages"] = ([{"role": "system", "content": system}] if system else []) + msgs
        if temp is not None:
            p["temperature"] = temp
        p.update(extra)
        return p

    def _request(self, payload: Dict[str, Any], stream: bool = False) -> requests.Response:
        headers = {**self._headers(), "Content-Type": "application/json"}
        if self.api == "anthropic":
            headers["anthropic-version"] = "2023-06-01"
        last: Optional[Exception] = None
        for attempt in range(self.retries + 1):
            try:
                r = self._session.post(self.url, headers=headers, json=payload, timeout=self.timeout, stream=stream)
            except requests.RequestException as ex:
                last = ex
                if attempt < self.retries:
                    time.sleep(self._backoff(attempt, None)); continue
                raise GatewayError(f"Lỗi mạng khi gọi {self.url}: {ex}", None, self.url) from None
            if r.status_code in (429, 500, 502, 503, 504) and attempt < self.retries:
                time.sleep(self._backoff(attempt, r.headers.get("Retry-After"))); r.close(); continue
            if r.status_code >= 400:
                body = r.text[:800]
                r.close()
                raise GatewayError(f"HTTP {r.status_code} từ {self.url} (model={payload.get('model')}): {body}",
                                   r.status_code, self.url, body)
            return r
        raise GatewayError(f"Gọi {self.url} thất bại: {last}", None, self.url)

    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        r = self._request(payload)
        try:
            return r.json()
        except ValueError:
            raise GatewayError(f"Phản hồi không phải JSON: {r.text[:400]}", r.status_code, self.url) from None

    @staticmethod
    def _backoff(attempt: int, retry_after: Optional[str]) -> float:
        try:
            if retry_after:
                return min(60.0, float(retry_after))
        except ValueError:
            pass
        return min(30.0, 2 ** attempt + random.random())

    @staticmethod
    def _blocks_text(c) -> str:
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            return "".join(b.get("text", "") for b in c if isinstance(b, dict) and b.get("type", "text") == "text")
        return ""

    def _parse(self, data: Dict[str, Any], model: str) -> ChatResponse:
        usage = data.get("usage") or {}
        if "choices" in data:
            ch = data["choices"][0]
            return ChatResponse(self._blocks_text(ch.get("message", {}).get("content", "")), data.get("model", model),
                                usage.get("prompt_tokens"), usage.get("completion_tokens"),
                                finish_reason=ch.get("finish_reason"), raw=data)
        if "content" in data:
            return ChatResponse(self._blocks_text(data["content"]), data.get("model", model),
                                usage.get("input_tokens"), usage.get("output_tokens"),
                                finish_reason=data.get("stop_reason"), raw=data)
        raise GatewayError(f"Không đọc được phản hồi: {str(data)[:400]}", None, self.url)

    def _delta_text(self, obj: Dict[str, Any]) -> str:
        if "choices" in obj and obj["choices"]:
            d = obj["choices"][0].get("delta") or {}
            return self._blocks_text(d.get("content") or "")
        if obj.get("type") == "content_block_delta":
            return (obj.get("delta") or {}).get("text", "") or ""
        return ""


class Conversation:
    """Hội thoại nhiều lượt: chat = llm.conversation(system='...'); chat.send('...')."""

    def __init__(self, connect: Connect, system: Optional[str] = None):
        self.connect, self.system = connect, system
        self.history: List[Dict[str, Any]] = []

    def send(self, text: str, **kw) -> str:
        self.history.append({"role": "user", "content": text})
        try:
            res = self.connect.chat(self.history, system=self.system, **kw)
        except Exception:
            self.history.pop()
            raise
        self.history.append({"role": "assistant", "content": res.text})
        return res.text

    def reset(self) -> None:
        self.history.clear()


def extract_json(text: str) -> Any:
    """Lấy object/array JSON đầu tiên trong chuỗi (chịu được ```json fences và dấu phẩy thừa)."""
    t = (text or "").strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", t, re.S)
    if m:
        t = m.group(1).strip()
    starts = [i for i in (t.find("{"), t.find("[")) if i >= 0]
    if not starts:
        raise ValueError("không thấy JSON")
    i = min(starts)
    j = t.rfind("}" if t[i] == "{" else "]")
    body = t[i:j + 1]
    try:
        return json.loads(body)
    except ValueError:
        return json.loads(re.sub(r",\s*([}\]])", r"\1", body))
