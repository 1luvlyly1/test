"""
Tự dò URL workspace và token Databricks.

Thứ tự (giống cell test đã chạy được trong notebook):
  host : tham số host → env DATABRICKS_HOST → spark.conf 'spark.databricks.workspaceUrl'
         → notebook context browserHostName → databricks-sdk Config.host
  token: tham số token → env DATABRICKS_TOKEN → token của notebook (dbutils context)
         → databricks-sdk Config.authenticate() (OAuth M2M trong Databricks Apps / Jobs dùng service principal)

Lưu ý: databricks-sdk trong notebook có thể trả về host VÙNG (vd https://singapore.cloud.databricks.com).
Route /ai-gateway/... không tồn tại ở host vùng → HTTP 404, nên host của SDK chỉ là phương án cuối.
"""
import os
from typing import Callable, Dict, Optional, Tuple

from ._errors import AuthError

def _normalize(host: str) -> str:
    host = host.strip().rstrip("/")
    return host if host.startswith("http") else "https://" + host


def _notebook_globals() -> Tuple[object, object]:
    """(spark, dbutils) nếu đang chạy trong notebook Databricks, ngược lại (None, None)."""
    spark = dbutils = None
    try:  # IPython namespace của notebook
        from IPython import get_ipython  # type: ignore
        ip = get_ipython()
        if ip is not None:
            spark = ip.user_ns.get("spark")
            dbutils = ip.user_ns.get("dbutils")
    except Exception:
        pass
    if dbutils is None:
        try:
            from databricks.sdk.runtime import dbutils as _d  # type: ignore
            dbutils = _d
        except Exception:
            pass
    if spark is None:
        try:
            from pyspark.sql import SparkSession  # type: ignore
            spark = SparkSession.getActiveSession()
        except Exception:
            pass
    return spark, dbutils


def _nb_context(dbutils):
    return dbutils.notebook.entry_point.getDbutils().notebook().getContext()


def resolve_host(explicit: Optional[str] = None) -> Tuple[str, str]:
    """Trả về (host, nguồn)."""
    if explicit:
        return _normalize(explicit), "tham số host"
    if os.environ.get("DATABRICKS_HOST"):
        return _normalize(os.environ["DATABRICKS_HOST"]), "env DATABRICKS_HOST"
    spark, dbutils = _notebook_globals()
    if spark is not None:
        try:
            url = spark.conf.get("spark.databricks.workspaceUrl")
            if url:
                return _normalize(url), "spark.databricks.workspaceUrl"
        except Exception:
            pass
    if dbutils is not None:
        try:
            url = _nb_context(dbutils).browserHostName().get()
            if url:
                return _normalize(url), "notebook context browserHostName"
        except Exception:
            pass
    try:
        from databricks.sdk import WorkspaceClient  # type: ignore
        h = WorkspaceClient().config.host
        if h:
            return _normalize(h), "databricks-sdk Config.host"
    except Exception:
        pass
    raise AuthError("Không xác định được URL workspace. Truyền Connect(host='https://<workspace-url>') "
                    "hoặc đặt biến môi trường DATABRICKS_HOST.")


def make_token_provider(explicit: Optional[str] = None) -> Tuple[Callable[[], Dict[str, str]], str]:
    """Trả về (hàm sinh header Authorization, nguồn). Hàm được gọi mỗi request để token luôn còn hạn."""
    if explicit:
        return (lambda: {"Authorization": f"Bearer {explicit}"}), "tham số token"
    if os.environ.get("DATABRICKS_TOKEN"):
        return (lambda: {"Authorization": f"Bearer {os.environ['DATABRICKS_TOKEN']}"}), "env DATABRICKS_TOKEN"
    _, dbutils = _notebook_globals()
    if dbutils is not None:
        try:
            _nb_context(dbutils).apiToken().get()

            def nb_token():
                return {"Authorization": f"Bearer {_nb_context(dbutils).apiToken().get()}"}
            return nb_token, "token notebook"
        except Exception:
            pass
    try:
        from databricks.sdk import WorkspaceClient  # type: ignore
        w = WorkspaceClient()
        w.config.authenticate()
        return (lambda: dict(w.config.authenticate())), f"databricks-sdk ({w.config.auth_type})"
    except Exception as ex:
        raise AuthError(f"Không lấy được token Databricks ({ex}). Truyền Connect(token=...) "
                        "hoặc đặt DATABRICKS_TOKEN.") from None
