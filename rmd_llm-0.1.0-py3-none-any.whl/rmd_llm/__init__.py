"""
rmd_llm – gọi Claude qua model service Unity AI Gateway (Databricks) chỉ với 1 dòng.

    %pip install /Volumes/analytics_ai/rmd_bau/libs/rmd_llm-0.1.0-py3-none-any.whl

    from rmd_llm import Connect, CallModel
    llm = Connect()                          # tự dò host + token
    llm.ask("Xin chào")                      # -> str

    call_model = CallModel()
    call_model.test_connection()
    call_model("Tóm tắt quy trình KYC")      # in chi tiết + trả về câu trả lời
"""
from ._errors import AuthError, GatewayError
from ._call import CallModel, call_model
from .connect import DEFAULT_MODEL_SERVICE, ROUTES, ChatResponse, Connect, Conversation, extract_json

__version__ = "0.1.0"
__all__ = ["Connect", "CallModel", "call_model", "ChatResponse", "Conversation", "GatewayError", "AuthError",
           "extract_json", "DEFAULT_MODEL_SERVICE", "ROUTES", "__version__"]
