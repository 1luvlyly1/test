"""Lỗi của SDK, kèm gợi ý xử lý bằng tiếng Việt."""
from typing import Optional

_HINTS = {
    400: "Payload không hợp lệ với route này. Thử Connect(api='anthropic') hoặc bỏ tham số không được hỗ trợ (vd temperature).",
    401: "Token không hợp lệ/hết hạn. Trong notebook: chạy lại cell; ngoài notebook: kiểm tra DATABRICKS_TOKEN.",
    403: "Tài khoản/service principal chưa có quyền EXECUTE (query) trên model service này trong Unity Catalog.",
    404: ("Không tìm thấy route/model. Kiểm tra: (1) host phải là URL workspace (spark.databricks.workspaceUrl), "
          "không phải host vùng như https://<region>.cloud.databricks.com; (2) tên model service đúng dạng "
          "catalog.schema.service; (3) workspace đã bật Unity AI Gateway."),
    429: "Vượt giới hạn tốc độ (rate limit) của model service. Giảm số luồng song song hoặc chờ rồi thử lại.",
}


class GatewayError(RuntimeError):
    """Lỗi khi gọi model qua Unity AI Gateway."""

    def __init__(self, message: str, status: Optional[int] = None, url: str = "", body: str = ""):
        self.status, self.url, self.body = status, url, body
        hint = _HINTS.get(status or 0, "")
        if status and status >= 500 and not hint:
            hint = "Lỗi phía máy chủ / model đang quá tải. Thử lại sau ít phút."
        self.hint = hint
        full = message + (f"\n→ Gợi ý: {hint}" if hint else "")
        super().__init__(full)


class AuthError(GatewayError):
    """Không xác định được host hoặc token Databricks."""
