"""
CallModel – lớp test nhanh: đưa 1 prompt, nhận câu trả lời, in kèm thông tin chẩn đoán.

    from rmd_llm import CallModel
    call_model = CallModel()
    call_model.test_connection()          # kiểm tra host/token/quyền
    answer = call_model("Tóm tắt quy trình KYC trong 3 ý")
"""
import textwrap
from typing import Optional

from .connect import ChatResponse, Connect
from ._errors import GatewayError


class CallModel:
    """
    Gọi model bằng 1 prompt và nhận câu trả lời.

    CallModel(connect=None, system=None, verbose=True, **connect_kwargs)
      connect        : dùng lại một Connect có sẵn; để trống thì tự tạo Connect(**connect_kwargs)
      system         : system prompt (tuỳ chọn)
      verbose        : in model, URL, thời gian, số token và câu trả lời
    Gọi: call_model("câu hỏi") -> str     |    call_model.run("câu hỏi") -> ChatResponse (đầy đủ)
    """

    def __init__(self, connect: Optional[Connect] = None, system: Optional[str] = None,
                 verbose: bool = True, **connect_kwargs):
        self.connect = connect or Connect(**connect_kwargs)
        self.system = system
        self.verbose = verbose

    def __call__(self, prompt: str, **kw) -> str:
        return self.run(prompt, **kw).text

    def run(self, prompt: str, **kw) -> ChatResponse:
        if not str(prompt or "").strip():
            raise ValueError("Prompt đang trống.")
        res = self.connect.chat(prompt, system=kw.pop("system", self.system), **kw)
        if self.verbose:
            self._print(prompt, res)
        return res

    def test_connection(self) -> bool:
        """In thông tin kết nối và gửi 1 câu ping. Trả về True nếu gọi được model."""
        info = self.connect.info()
        print("── rmd_llm · kiểm tra kết nối " + "─" * 30)
        for k, label in (("model_service", "Model service"), ("api", "API"), ("url", "URL"),
                         ("host_source", "Host lấy từ"), ("auth_source", "Token lấy từ")):
            print(f"{label:<14}: {info[k]}")
        try:
            res = self.connect.ping()
            print(f"{'Kết quả':<14}: ✅ OK – model trả lời '{res.text.strip()[:40]}' sau {res.latency_s}s")
            return True
        except GatewayError as ex:
            print(f"{'Kết quả':<14}: ❌ {ex}")
            return False

    def _print(self, prompt: str, res: ChatResponse) -> None:
        p = prompt if len(prompt) <= 300 else prompt[:300] + "…"
        tok = f"{res.input_tokens}→{res.output_tokens} tokens" if res.input_tokens is not None else "tokens: n/a"
        print("── rmd_llm · call_model " + "─" * 36)
        print(f"Model  : {self.connect.model_service}")
        print("Prompt : " + textwrap.indent(p, " " * 9).lstrip())
        print(f"Trả lời ({res.latency_s}s · {tok}):")
        print(res.text)
        print("─" * 60)


_default: Optional[CallModel] = None


def call_model(prompt: str, **kw) -> str:
    """Hàm một dòng: call_model('câu hỏi') -> câu trả lời (dùng Connect mặc định, không in chi tiết)."""
    global _default
    if _default is None:
        _default = CallModel(verbose=False)
    return _default(prompt, **kw)
